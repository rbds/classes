#!/bin/bash

export GAZEBO_MODEL_PATH=/media/randy/SpinnyHarddrive/classes/Robotics/HW1/feedback_control
export GAZEBO_PLUGIN_PATH=/media/randy/SpinnyHarddrive/classes/Robotics/HW1/feedback_control/build

echo Path Setup Complete
