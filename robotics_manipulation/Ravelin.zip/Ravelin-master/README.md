Ravelin
=======

Robotics Matrix Vector Linear Algebra library